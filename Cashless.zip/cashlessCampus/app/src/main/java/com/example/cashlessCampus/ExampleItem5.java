package com.example.cashlessCampus;

public class ExampleItem5 {
    private String mText0;
    private String mText1;
    private String mText2;

    public ExampleItem5(String text0, String text1, String text2) {
        this.mText0 = text0;
        this.mText1 = text1;
        this.mText2 = text2;
    }

    public String getText0() {
        return this.mText0;
    }

    public String getText1() {
        return this.mText1;
    }

    public String getText2() {
        return this.mText2;
    }


}