package com.example.cashlessCampus;

public class UrlLinks {
    public static String urlserver="";

    public static String urlserverpython="http://192.168.150.162:5000/";
    public static String registrationurl=urlserver+"registerUser";

    public static String pyregister=urlserverpython+"userRegister";
    public static String pylogin=urlserverpython+"userLogin";

    public static String uploadimg=urlserverpython+"uploadimg";
    public static String uploadItems=urlserverpython+"uploadItems";
    public static String updateItems=urlserverpython+"updateItems";
    public static String deleteItem=urlserverpython+"deleteItem";

    public static String getAllItems=urlserverpython+"getAllItems";
    public static String getAllEvents=urlserverpython+"getAllEvents";
    public static String getAllItems1=urlserverpython+"getAllItems1";
    public static String getSumCount=urlserverpython+"getSumCount";
    public static String paybill=urlserverpython+"paybill";
    public static String issuebook=urlserverpython+"issuebook";
    public static String getBalance=urlserverpython+"getBalance";
    public static String getHistory=urlserverpython+"getHistory";
    public static String getAllHistory=urlserverpython+"getAllHistory";
    public static String getAllUsers=urlserverpython+"getAllUsers";
    public static String sendQuery=urlserverpython+"sendQuery";
    public static String makeNotification=urlserverpython+"makeNotification";


    public static String updateFunds=urlserverpython+"updateFunds";
    public static String Enroll=urlserverpython+"Enroll";

}
